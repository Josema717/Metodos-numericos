function y = fprime(x)
    y = 6*exp(6*x)+6*log(2)^2*exp(2*x)-4*log(8)*exp(4*x);
end