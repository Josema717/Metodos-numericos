function y = g(x)
    y = x-(exp(6*x)+(3*log(2)^2*exp(2*x))-(log(8)*exp(4*x))-(log(2)^3));
end